import React, { useState, useEffect } from "react";
import "./App.css";

function App() {
  const [currentSum, setCurrentSum] = useState(0);
  const [clear, setClear] = useState(false);

  useEffect(() => {
    document.querySelector("#result").value = "";
  }, []);

  useEffect(() => {
    if (clear) document.querySelector("#result").value = "";
  });

  const Add = (e) => {
    e.preventDefault();
    if (clear) setClear(false);
    let currentNum = document.querySelector("#num").value;
    if (currentNum === "") return;
    let sum = currentSum + parseInt(currentNum);
    setCurrentSum(sum);
    document.querySelector("#num").value = "";
  };

  const Sub = (e) => {
    e.preventDefault();
    if (clear) setClear(false);
    let currentNum = document.querySelector("#num").value;
    if (currentNum === "") return;
    let sum = currentSum - parseInt(currentNum);
    setCurrentSum(sum);
    document.querySelector("#num").value = "";
  };

  const Clear = (e) => {
    e.preventDefault();
    console.log("sum:", currentSum);
    document.querySelector("form").reset();
    setClear(true);
    setCurrentSum(0);
  };

  return (
    <div className="App ">
      <div className="app-title">
        <h1>Enter a value to add/ Substract</h1>
      </div>
      <form>
        <input className="my-2 mx-2" type="text" id="num" placeholder="Enter a number" />
        <div className="button">
          <button className="btn btn-primary mx-3 my-3" onClick={Add}>
            Add
          </button>
          <button className="btn btn-primary mx-3 my-3" onClick={Sub}>
            Substract
          </button>
          <button className="btn btn-danger mx-3 my-3" onClick={Clear}>
            Clear
          </button>
        </div>
        Result : <br />
        <input className="my-2 mx-2" type="text" id="result" value={currentSum} readOnly />
      </form>
    </div>

    // <>
    //   <div className="mb-3">
    //     <label className="form-label">Enter a value to Add / Substract</label>
    //     <input
    //       type="number"
    //       id="num"
    //       className="form-control"
    //       placeholder="Enter a number here... "
    //     />
    //   </div>
    //   <div className="mb-3">
    //     <button type="button" class="btn btn-primary" onClick={Add}>
    //      Add
    //     </button>
    //     <button type="button" class="btn btn-primary">
    //       Substract
    //     </button>
    //     <button type="button" class="btn btn-danger" onClick={Clear}>
    //       Clear
    //     </button>
    //   </div>
    //   <div className="mb-3">
    //     <label className="form-label">Result</label>
    //     <input type="text" className="form-control"  id="result"  value={currentSum}></input>
    //   </div>
    // </>
  );
}

export default App;
