import React from 'react';
import './App.css';
import Home from './pages/Home'
function App() {
  return (
    <main>
        <Home/>
    </main>
  );
}

export default App;