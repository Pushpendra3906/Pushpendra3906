import Collect from "../components/Collect";


const Home=()=>{
    return (
        <div>
           <Collect/>
        </div>
    )
}
export default Home;