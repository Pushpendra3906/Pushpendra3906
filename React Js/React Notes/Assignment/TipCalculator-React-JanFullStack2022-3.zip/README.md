# Tip-Calculator-in-React
Instructions Refer to the attached document for building a tip calculator for the restaurant owner. 



CREATE REACT APPAs a restaurant owner, I want to calculate the total tip offered by various customer according to their experience.For example,if the experience is excellent and the total billof the customeris 2000 The total tip would be 20% of 2000 i.e.400 Rs. You need to show Customer Name and the tip amount 400 as an outputfor each customer. Refer to the attached image for the functionality UI. 


![image](https://user-images.githubusercontent.com/69638895/115364159-bb2d8180-a1e0-11eb-8afc-8755849892b1.png)

Create functionalities as mentioned in the Image in react with the following:1.Create a bill amount field. 2.Create a text input for entering the name of the customers.
3.Create a select tag for service rating, based on the rating the tip amount will be calculated and displayed. for example:total bill amount: 2000Service 1: excellent (20%)           Service 2: Moderate (10%)          Service 3: bad (5%)                4.Tip from customer 1: (2000) * 20%   -Customer tip -400 RsTip from customer 2: (2500) * 10% -Customertip -250 RsTip from customer 3: (5000) * 5% -Customertip -250 Rs5.When customer clicks on Add customer buttonafter filling the details, calculate and display the tip for the customer and add the details to the output area dynamically.6.Add a Calculate button to view total customersand total tippaid.
