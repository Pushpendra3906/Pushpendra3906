import Todo from "../container/Todo/Todo";

const Home = () => {
  return <Todo title="Old School Todo App" />;
};

export default Home;
