import Todo from "../components/Todo/Todo";

const Home = () => {
  return (
    <>
      <h1>Todo App</h1>
      <Todo />
    </>
  );
};

export default Home;
