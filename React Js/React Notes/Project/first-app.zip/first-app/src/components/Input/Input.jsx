const Input = (props) => (
    <input type="text" onChange={props.changeHandler}/>
);

export default Input;