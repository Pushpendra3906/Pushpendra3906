const Text = (props) => (
    <h3>{props.msg}</h3>
);

export default Text;