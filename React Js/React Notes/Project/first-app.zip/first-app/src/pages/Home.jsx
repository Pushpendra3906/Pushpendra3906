import InputText from '../components/InputText/InputText';

const Home = () => (
    <>
        <h1>Home Page</h1>
        <InputText />
    </>
);

export default Home;